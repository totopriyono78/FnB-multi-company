<?php

use App\Prototype\DemoPos;
use App\Prototype\PosBridge;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/admin');

/*
 * PROTOTIPE tampilan aplikasi POS (FR-POS, Tahap 6).
 *
 * Bila data demo tersedia, layar memakai katalog nyata milik company demo dan
 * tombol Bayar menyimpan transaksi sungguhan lewat mesin penjualan (OrderRecorder),
 * sehingga hasilnya langsung terlihat di back-office. Bila tidak, layar tetap
 * jalan dengan katalog contoh statis (tanpa simpan).
 *
 * Dimatikan dengan FNB_PROTOTYPE_POS=false; penyimpanan saja dimatikan dengan
 * FNB_PROTOTYPE_POS_LIVE=false.
 */
Route::get('/pos', function (PosBridge $bridge) {
    abort_unless((bool) config('fnb.prototype_pos', true), 404);

    $live = $bridge->snapshot();
    $cashier = $live['cashier'] ?? 'Dewi Anggraini';

    return view('prototype.pos', [
        'live' => $live !== null,
        'menu' => $live['menu'] ?? DemoPos::menuWithImages(),
        'outlet' => $live['outlet'] ?? 'Resto Kemang',
        'address' => $live['address'] ?? 'Jl. Kemang Raya No. 24, Jakarta Selatan',
        'outletCode' => $live['outlet_code'] ?? 'KMG',
        'device' => $live['device'] ?? 'POS-01',
        'cashier' => $cashier,
        'pricing' => $live['pricing'] ?? [
            'tax_name' => 'PB1',
            'tax_rate' => 10,
            'tax_inclusive' => false,
            'service_charge_rate' => 5,
            'service_charge_applies' => true,
            'rounding_unit' => 100,
        ],
        'businessDate' => now()->translatedFormat('d M Y'),
        'receiptDate' => now()->format('ymd'),
    ]);
})->name('prototype.pos');

/** Simpan transaksi dari layar POS prototipe ke sistem (hanya bila data demo tersedia). */
Route::post('/pos/order', function (Request $request, PosBridge $bridge) {
    abort_unless((bool) config('fnb.prototype_pos', true), 404);
    abort_unless($bridge->enabled(), 404);

    $data = $request->validate([
        'lines' => ['required', 'array', 'min:1', 'max:50'],
        'lines.*.item_id' => ['required', 'uuid'],
        'lines.*.qty' => ['required', 'integer', 'between:1,99'],
        'channel' => ['required', 'string', 'max:30'],
        'method' => ['required', 'string', 'in:cash,debit,credit'],
        'tendered' => ['nullable', 'numeric', 'min:0'],
        'table' => ['nullable', 'string', 'max:30'],
    ]);

    try {
        return response()->json($bridge->checkout(
            lines: $data['lines'],
            channelCode: $data['channel'],
            method: $data['method'],
            tendered: isset($data['tendered']) ? (string) $data['tendered'] : null,
            table: $data['table'] ?? null,
        ));
    } catch (\Throwable $e) {
        report($e);

        return response()->json(['message' => $e->getMessage()], 422);
    }
})->name('prototype.pos.order');
