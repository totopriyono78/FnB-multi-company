<?php

use App\Prototype\DemoPos;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/admin');

/*
 * PROTOTIPE tampilan aplikasi POS (FR-POS, Tahap 6).
 * Layar demo tanpa basis data: memperlihatkan alur kasir dari pilih menu sampai struk.
 * Dimatikan dengan FNB_PROTOTYPE_POS=false.
 */
Route::get('/pos', function () {
    abort_unless((bool) config('fnb.prototype_pos', true), 404);

    $cashier = 'Dewi Anggraini';

    return view('prototype.pos', [
        'menu' => DemoPos::menu(),
        'outlet' => 'Resto Kemang',
        'cashier' => $cashier,
        'initials' => collect(explode(' ', $cashier))->take(2)->map(fn ($p) => mb_substr($p, 0, 1))->implode(''),
        'businessDate' => now()->translatedFormat('d M Y'),
        'receiptDate' => now()->format('ymd'),
    ]);
})->name('prototype.pos');
