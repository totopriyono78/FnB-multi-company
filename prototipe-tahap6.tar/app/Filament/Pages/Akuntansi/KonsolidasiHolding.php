<?php

namespace App\Filament\Pages\Akuntansi;

use App\Filament\Prototype\DemoBooks;
use Filament\Pages\Page;

/**
 * PROTOTIPE tampilan modul Akuntansi (belum tersambung ke basis data).
 */
class KonsolidasiHolding extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-plus';

    protected static ?string $navigationGroup = 'Akuntansi (Prototipe)';

    protected static ?string $navigationLabel = 'Konsolidasi Holding';

    protected static ?string $title = 'Konsolidasi Holding';

    protected static ?string $slug = 'akuntansi/konsolidasi';

    protected static ?int $navigationSort = 6;

    protected static string $view = 'filament.pages.akuntansi.konsolidasi';

    public static function shouldRegisterNavigation(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public static function canAccess(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public function books(): string
    {
        return DemoBooks::class;
    }
}
