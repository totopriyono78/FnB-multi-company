<?php

namespace App\Filament\Pages\Akuntansi;

use App\Filament\Prototype\DemoBooks;
use Filament\Pages\Page;

/**
 * PROTOTIPE tampilan modul Akuntansi (belum tersambung ke basis data).
 */
class AsetSewa extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-truck';

    protected static ?string $navigationGroup = 'Akuntansi (Prototipe)';

    protected static ?string $navigationLabel = 'Aset & Sewa';

    protected static ?string $title = 'Aset & Sewa';

    protected static ?string $slug = 'akuntansi/aset-sewa';

    protected static ?int $navigationSort = 7;

    protected static string $view = 'filament.pages.akuntansi.aset-sewa';

    public static function shouldRegisterNavigation(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public static function canAccess(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public function books(): string
    {
        return DemoBooks::class;
    }
}
