<?php

namespace App\Filament\Pages\Akuntansi;

use App\Filament\Prototype\DemoBooks;
use Filament\Pages\Page;

/**
 * PROTOTIPE tampilan modul Akuntansi (belum tersambung ke basis data).
 */
class BaganAkun extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-list-bullet';

    protected static ?string $navigationGroup = 'Akuntansi (Prototipe)';

    protected static ?string $navigationLabel = 'Bagan Akun (COA)';

    protected static ?string $title = 'Bagan Akun (COA)';

    protected static ?string $slug = 'akuntansi/bagan-akun';

    protected static ?int $navigationSort = 2;

    protected static string $view = 'filament.pages.akuntansi.bagan-akun';

    public static function shouldRegisterNavigation(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public static function canAccess(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public function books(): string
    {
        return DemoBooks::class;
    }
}
