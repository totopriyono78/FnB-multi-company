<?php

namespace App\Filament\Pages\Akuntansi;

use App\Filament\Prototype\DemoBooks;
use Filament\Pages\Page;

/**
 * PROTOTIPE tampilan modul Akuntansi (belum tersambung ke basis data).
 */
class HoldingDashboard extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-building-office-2';

    protected static ?string $navigationGroup = 'Akuntansi (Prototipe)';

    protected static ?string $navigationLabel = 'Dashboard Holding';

    protected static ?string $title = 'Dashboard Holding';

    protected static ?string $slug = 'akuntansi/holding';

    protected static ?int $navigationSort = 1;

    protected static string $view = 'filament.pages.akuntansi.holding-dashboard';

    public static function shouldRegisterNavigation(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public static function canAccess(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public function books(): string
    {
        return DemoBooks::class;
    }
}
