<?php

namespace App\Filament\Pages\Akuntansi;

use App\Filament\Prototype\DemoBooks;
use Filament\Pages\Page;

/**
 * PROTOTIPE tampilan modul Akuntansi (belum tersambung ke basis data).
 */
class LaporanKeuangan extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-chart-bar';

    protected static ?string $navigationGroup = 'Akuntansi (Prototipe)';

    protected static ?string $navigationLabel = 'Laporan Keuangan';

    protected static ?string $title = 'Laporan Keuangan';

    protected static ?string $slug = 'akuntansi/laporan-keuangan';

    protected static ?int $navigationSort = 5;

    protected static string $view = 'filament.pages.akuntansi.laporan-keuangan';

    public static function shouldRegisterNavigation(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public static function canAccess(): bool
    {
        return (bool) config('fnb.prototype_accounting', true);
    }

    public function books(): string
    {
        return DemoBooks::class;
    }
}
