<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>FnB Cloud POS — {{ $outlet }}</title>
<style>
  :root{--bg:#0f172a;--panel:#111c33;--card:#ffffff;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;
        --brand:#1e2761;--brand2:#2b3a7a;--amber:#d98b1f;--green:#15803d;--soft:#f1f5f9;}
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  html,body{margin:0;height:100%;font-family:"Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;background:var(--bg);color:var(--ink);overflow:hidden}
  .app{display:flex;height:100vh}
  .rail{width:78px;background:var(--brand);display:flex;flex-direction:column;align-items:center;padding:10px 0;gap:4px;flex:0 0 auto}
  .rail .logo{color:#fff;font-weight:800;font-size:13px;letter-spacing:.5px;text-align:center;line-height:1.1;margin-bottom:10px}
  .rail button{width:62px;height:58px;border:0;border-radius:12px;background:transparent;color:#c7d2fe;font-size:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;cursor:pointer}
  .rail button span{font-size:19px;line-height:1}
  .rail button.on,.rail button:hover{background:rgba(255,255,255,.14);color:#fff}
  .rail .spacer{flex:1}
  .main{flex:1;display:flex;flex-direction:column;background:#f8fafc;min-width:0}
  .top{height:56px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:14px;padding:0 16px;flex:0 0 auto}
  .top .out{font-weight:700;font-size:14px}
  .top .sub{font-size:11px;color:var(--muted)}
  .pill{font-size:11px;font-weight:600;padding:3px 9px;border-radius:999px;background:#dcfce7;color:#166534}
  .pill.warn{background:#fef3c7;color:#92400e}
  .pill.info{background:#e0e7ff;color:#3730a3}
  .top .right{margin-left:auto;display:flex;align-items:center;gap:10px}
  .avatar{width:32px;height:32px;border-radius:50%;background:var(--brand);color:#fff;display:grid;place-items:center;font-size:12px;font-weight:700}
  .body{flex:1;display:flex;min-height:0}
  .left{flex:1;display:flex;flex-direction:column;min-width:0}
  .cats{display:flex;gap:8px;padding:12px 16px 6px;overflow-x:auto;flex:0 0 auto}
  .cats button{border:1px solid var(--line);background:#fff;border-radius:999px;padding:7px 14px;font-size:13px;font-weight:600;color:#334155;cursor:pointer;white-space:nowrap}
  .cats button.on{background:var(--brand);border-color:var(--brand);color:#fff}
  .search{padding:4px 16px 8px}
  .search input{width:100%;padding:9px 12px;border:1px solid var(--line);border-radius:10px;font-size:13px;background:#fff}
  .grid{flex:1;overflow-y:auto;padding:4px 16px 16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:10px;align-content:start}
  .item{background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px;cursor:pointer;display:flex;flex-direction:column;gap:6px;text-align:left}
  .item:active{transform:scale(.98)}
  .item .thumb{height:62px;border-radius:10px;display:grid;place-items:center;font-size:22px}
  .item .nm{font-size:12.5px;font-weight:600;line-height:1.25;min-height:32px}
  .item .pr{font-size:12.5px;font-weight:700;color:var(--brand)}
  .item .tag{font-size:10px;color:var(--muted)}
  .item.out{opacity:.45}
  .cart{width:360px;flex:0 0 auto;background:#fff;border-left:1px solid var(--line);display:flex;flex-direction:column}
  .cart .ch{padding:12px 14px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:8px}
  .cart .ch b{font-size:14px}
  .types{display:flex;gap:6px;padding:10px 14px 4px}
  .types button{flex:1;border:1px solid var(--line);background:#fff;border-radius:9px;padding:7px 4px;font-size:11.5px;font-weight:600;color:#334155;cursor:pointer}
  .types button.on{background:#eef2ff;border-color:var(--brand);color:var(--brand)}
  .lines{flex:1;overflow-y:auto;padding:8px 14px}
  .line{display:flex;gap:8px;padding:8px 0;border-bottom:1px dashed var(--line)}
  .line .nm{flex:1;font-size:12.5px;font-weight:600}
  .line .mod{font-size:10.5px;color:var(--muted);font-weight:400}
  .line .amt{font-size:12.5px;font-weight:700;white-space:nowrap}
  .qty{display:flex;align-items:center;gap:6px}
  .qty button{width:24px;height:24px;border-radius:7px;border:1px solid var(--line);background:#fff;font-size:14px;line-height:1;cursor:pointer}
  .qty span{font-size:12.5px;font-weight:700;min-width:16px;text-align:center}
  .empty{color:var(--muted);font-size:12.5px;text-align:center;padding:36px 10px;line-height:1.6}
  .sum{border-top:1px solid var(--line);padding:10px 14px;font-size:12.5px}
  .sum div{display:flex;justify-content:space-between;padding:2px 0;color:#334155}
  .sum .tot{font-size:17px;font-weight:800;color:var(--ink);padding-top:6px;margin-top:4px;border-top:1px solid var(--line)}
  .acts{padding:10px 14px 14px;display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .btn{border:0;border-radius:11px;padding:12px 10px;font-size:13px;font-weight:700;cursor:pointer}
  .btn.ghost{background:#eef2ff;color:var(--brand)}
  .btn.amber{background:#fff7ed;color:#9a3412;border:1px solid #fed7aa}
  .btn.pay{grid-column:1/-1;background:var(--green);color:#fff;font-size:15px;padding:14px}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .modal{position:fixed;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:20px;z-index:40}
  .modal.on{display:flex}
  .sheet{background:#fff;border-radius:16px;width:100%;max-width:520px;max-height:92vh;overflow:auto;padding:18px}
  .sheet h3{margin:0 0 4px;font-size:17px}
  .sheet p.s{margin:0 0 14px;font-size:12px;color:var(--muted)}
  .pays{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
  .pays button{border:1px solid var(--line);background:#fff;border-radius:11px;padding:12px 6px;font-size:12px;font-weight:700;cursor:pointer}
  .pays button.on{border-color:var(--green);background:#f0fdf4;color:var(--green)}
  .cash{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
  .cash button{border:1px solid var(--line);background:#fff;border-radius:10px;padding:10px 4px;font-size:12px;font-weight:600;cursor:pointer}
  .rcpt{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px;background:var(--soft);border-radius:12px;padding:14px;white-space:pre-wrap;line-height:1.5}
  .scr{display:none;flex:1;overflow:auto;padding:18px}
  .scr.on{display:block}
  .scr h2{margin:0 0 4px;font-size:17px}
  .scr p.d{margin:0 0 14px;font-size:12.5px;color:var(--muted)}
  table.t{width:100%;border-collapse:collapse;font-size:12.5px;background:#fff;border-radius:12px;overflow:hidden}
  table.t th,table.t td{padding:9px 12px;text-align:left;border-bottom:1px solid var(--line)}
  table.t th{background:#f1f5f9;font-size:11px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted)}
  table.t td.n,table.t th.n{text-align:right}
  .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-bottom:16px}
  .kpi{background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px 14px}
  .kpi h4{margin:0 0 4px;font-size:11px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted)}
  .kpi .v{font-size:19px;font-weight:800}
  .kpi .s{font-size:11px;color:var(--muted);margin-top:2px}
  .banner{background:#fff7ed;border:1px dashed var(--amber);color:#7c2d12;font-size:11.5px;padding:7px 12px;border-radius:9px;margin:10px 16px 0}
  @media (max-width:960px){.cart{width:300px}.rail{width:64px}.rail button{width:54px}}
</style>
</head>
<body>
<div class="app">
  <nav class="rail">
    <div class="logo">FnB<br>Cloud</div>
    <button class="on" data-scr="kasir"><span>🧾</span>Kasir</button>
    <button data-scr="pesanan"><span>📋</span>Pesanan</button>
    <button data-scr="shift"><span>💰</span>Shift</button>
    <button data-scr="stok"><span>📦</span>Stok</button>
    <button data-scr="laporan"><span>📊</span>Laporan</button>
    <div class="spacer"></div>
    <button data-scr="pengaturan"><span>⚙️</span>Atur</button>
  </nav>

  <div class="main">
    <header class="top">
      <div>
        <div class="out">{{ $outlet }}</div>
        <div class="sub">Perangkat POS-01 · Hari bisnis {{ $businessDate }}</div>
      </div>
      <span class="pill">● Online</span>
      <span class="pill info">Shift aktif 07.00</span>
      <div class="right">
        <div style="text-align:right">
          <div style="font-size:12.5px;font-weight:700" id="clock">--:--</div>
          <div class="sub">Kasir: {{ $cashier }}</div>
        </div>
        <div class="avatar">{{ $initials }}</div>
      </div>
    </header>

    <div class="banner">Prototipe tampilan POS — data contoh, transaksi tidak disimpan. Dipakai untuk memperlihatkan alur kasir.</div>

    <div class="body">
      <!-- ============ KASIR ============ -->
      <div class="left" id="scr-kasir">
        <div class="cats" id="cats"></div>
        <div class="search"><input id="q" placeholder="Cari menu atau pindai barcode…"></div>
        <div class="grid" id="grid"></div>
      </div>

      <!-- ============ LAYAR LAIN ============ -->
      <div class="scr" id="scr-pesanan">
        <h2>Pesanan berjalan</h2>
        <p class="d">Pesanan yang sedang diproses dapur dan yang ditahan kasir.</p>
        <table class="t">
          <thead><tr><th>No. struk</th><th>Meja / tipe</th><th>Item</th><th>Status</th><th>Dibuka</th><th class="n">Nilai</th></tr></thead>
          <tbody>
            <tr><td>KMG-01-260920-0042</td><td>Meja 12 · Dine-in</td><td>4 item</td><td><span class="pill warn">Diproses dapur</span></td><td>19.42</td><td class="n">Rp 248.000</td></tr>
            <tr><td>KMG-01-260920-0041</td><td>Bawa pulang</td><td>2 item</td><td><span class="pill">Siap diambil</span></td><td>19.35</td><td class="n">Rp 96.000</td></tr>
            <tr><td>KMG-01-260920-0040</td><td>Meja 5 · Dine-in</td><td>7 item</td><td><span class="pill info">Ditahan</span></td><td>19.20</td><td class="n">Rp 412.000</td></tr>
            <tr><td>KMG-01-260920-0039</td><td>Delivery · GoFood</td><td>3 item</td><td><span class="pill warn">Diproses dapur</span></td><td>19.11</td><td class="n">Rp 154.000</td></tr>
          </tbody>
        </table>
      </div>

      <div class="scr" id="scr-shift">
        <h2>Shift kasir</h2>
        <p class="d">Buka kas, setoran, dan selisih kas — dasar jurnal penjualan harian.</p>
        <div class="kpis">
          <div class="kpi"><h4>Modal awal</h4><div class="v">Rp 500.000</div><div class="s">Dibuka 07.00 oleh {{ $cashier }}</div></div>
          <div class="kpi"><h4>Penjualan tunai</h4><div class="v">Rp 4.860.000</div><div class="s">38 transaksi</div></div>
          <div class="kpi"><h4>Non-tunai</h4><div class="v">Rp 7.240.000</div><div class="s">QRIS 24 · Kartu 9</div></div>
          <div class="kpi"><h4>Kas seharusnya</h4><div class="v">Rp 5.360.000</div><div class="s">Modal + tunai − pengeluaran</div></div>
        </div>
        <table class="t">
          <thead><tr><th>Waktu</th><th>Kejadian</th><th>Oleh</th><th class="n">Nilai</th></tr></thead>
          <tbody>
            <tr><td>07.00</td><td>Buka shift — modal awal</td><td>{{ $cashier }}</td><td class="n">Rp 500.000</td></tr>
            <tr><td>12.15</td><td>Pengeluaran kas kecil — es batu</td><td>{{ $cashier }}</td><td class="n">Rp 120.000</td></tr>
            <tr><td>15.40</td><td>Void transaksi (otorisasi supervisor)</td><td>Supervisor Dimas</td><td class="n">Rp 84.000</td></tr>
            <tr><td>18.02</td><td>Setoran tunai sementara ke brankas</td><td>{{ $cashier }}</td><td class="n">Rp 2.000.000</td></tr>
          </tbody>
        </table>
      </div>

      <div class="scr" id="scr-stok">
        <h2>Stok cepat</h2>
        <p class="d">Menu yang stoknya menipis atau dimatikan sementara (sold out) dari POS.</p>
        <table class="t">
          <thead><tr><th>Menu / bahan</th><th>Status</th><th class="n">Sisa</th><th>Tindakan</th></tr></thead>
          <tbody>
            <tr><td>Iga Bakar Madu</td><td><span class="pill warn">Menipis</span></td><td class="n">6 porsi</td><td>Tandai habis</td></tr>
            <tr><td>Es Kopi Susu Gula Aren</td><td><span class="pill">Aman</span></td><td class="n">48 porsi</td><td>—</td></tr>
            <tr><td>Nasi Goreng Kampung</td><td><span class="pill warn">Menipis</span></td><td class="n">9 porsi</td><td>Tandai habis</td></tr>
            <tr><td>Sop Buntut</td><td><span class="pill info">Habis hari ini</span></td><td class="n">0</td><td>Aktifkan lagi</td></tr>
          </tbody>
        </table>
      </div>

      <div class="scr" id="scr-laporan">
        <h2>Ringkasan hari ini</h2>
        <p class="d">Angka yang sama akan mengalir ke pembukuan sebagai jurnal penjualan saat tutup hari.</p>
        <div class="kpis">
          <div class="kpi"><h4>Penjualan bersih</h4><div class="v">Rp 11.180.000</div><div class="s">71 transaksi · rata-rata Rp 157.000</div></div>
          <div class="kpi"><h4>Pajak (PB1 10%)</h4><div class="v">Rp 1.118.000</div><div class="s">Dipisah per transaksi</div></div>
          <div class="kpi"><h4>Diskon &amp; promo</h4><div class="v">Rp 386.000</div><div class="s">12 transaksi</div></div>
          <div class="kpi"><h4>Void</h4><div class="v">2</div><div class="s">Semua dengan otorisasi supervisor</div></div>
        </div>
        <table class="t">
          <thead><tr><th>Menu terlaris</th><th class="n">Terjual</th><th class="n">Penjualan</th></tr></thead>
          <tbody>
            <tr><td>Es Kopi Susu Gula Aren</td><td class="n">64</td><td class="n">Rp 1.472.000</td></tr>
            <tr><td>Nasi Goreng Kampung</td><td class="n">41</td><td class="n">Rp 1.804.000</td></tr>
            <tr><td>Ayam Bakar Taliwang</td><td class="n">33</td><td class="n">Rp 2.079.000</td></tr>
            <tr><td>Iga Bakar Madu</td><td class="n">22</td><td class="n">Rp 2.068.000</td></tr>
          </tbody>
        </table>
      </div>

      <div class="scr" id="scr-pengaturan">
        <h2>Pengaturan perangkat</h2>
        <p class="d">Pengaturan yang dipakai kasir di lapangan.</p>
        <table class="t">
          <thead><tr><th>Pengaturan</th><th>Nilai</th></tr></thead>
          <tbody>
            <tr><td>Printer struk</td><td>EPSON TM-T82 (80 mm) — LAN 192.168.1.50</td></tr>
            <tr><td>Printer dapur</td><td>Stasiun Dapur &amp; Bar (2 printer)</td></tr>
            <tr><td>Pembulatan</td><td>Rp 100 — berlaku juga untuk non-tunai</td></tr>
            <tr><td>Pajak</td><td>PB1 10% · service charge 5%</td></tr>
            <tr><td>Mode offline</td><td>Aktif — transaksi tersimpan lokal dan dikirim otomatis</td></tr>
            <tr><td>Antrian belum terkirim</td><td>0 transaksi</td></tr>
          </tbody>
        </table>
      </div>

      <!-- ============ KERANJANG ============ -->
      <aside class="cart" id="cartPanel">
        <div class="ch"><b>Pesanan baru</b><span class="pill info" id="orderNo">KMG-01-{{ $receiptDate }}-0043</span></div>
        <div class="types">
          <button class="on" data-type="Dine-in">🍽️ Dine-in</button>
          <button data-type="Bawa pulang">🥡 Bawa pulang</button>
          <button data-type="Delivery">🛵 Delivery</button>
        </div>
        <div class="lines" id="lines"><div class="empty">Belum ada item.<br>Ketuk menu di sebelah kiri untuk menambahkan.</div></div>
        <div class="sum">
          <div><span>Subtotal</span><span id="sSub">Rp 0</span></div>
          <div><span>Diskon</span><span id="sDisc">Rp 0</span></div>
          <div><span>Service charge 5%</span><span id="sServ">Rp 0</span></div>
          <div><span>PB1 10%</span><span id="sTax">Rp 0</span></div>
          <div><span>Pembulatan</span><span id="sRound">Rp 0</span></div>
          <div class="tot"><span>Total</span><span id="sTotal">Rp 0</span></div>
        </div>
        <div class="acts">
          <button class="btn ghost" onclick="hold()">Tahan pesanan</button>
          <button class="btn amber" onclick="kitchen()">Kirim ke dapur</button>
          <button class="btn pay" id="payBtn" onclick="openPay()" disabled>Bayar</button>
        </div>
      </aside>
    </div>
  </div>
</div>

<div class="modal" id="payModal">
  <div class="sheet">
    <h3>Pembayaran</h3>
    <p class="s">Total tagihan <b id="payTotal">Rp 0</b> · <span id="payCount">0</span> item</p>
    <div class="pays">
      <button class="on" data-pay="Tunai">💵 Tunai</button>
      <button data-pay="QRIS">📱 QRIS</button>
      <button data-pay="Kartu">💳 Kartu / EDC</button>
    </div>
    <div id="cashBox">
      <div class="cash" id="cashBtns"></div>
      <div style="display:flex;justify-content:space-between;font-size:13px;padding:6px 2px 12px">
        <span>Uang diterima <b id="cashGiven">Rp 0</b></span>
        <span>Kembalian <b id="cashBack">Rp 0</b></span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <button class="btn ghost" onclick="closePay()">Batal</button>
      <button class="btn pay" style="grid-column:auto" onclick="finish()">Selesaikan &amp; cetak struk</button>
    </div>
  </div>
</div>

<div class="modal" id="rcptModal">
  <div class="sheet">
    <h3>Struk</h3>
    <p class="s">Pratinjau struk 80 mm — juga dapat dikirim sebagai struk digital.</p>
    <div class="rcpt" id="rcpt"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px">
      <button class="btn ghost" onclick="document.getElementById('rcptModal').classList.remove('on')">Tutup</button>
      <button class="btn pay" style="grid-column:auto" onclick="newOrder()">Transaksi baru</button>
    </div>
  </div>
</div>

<script>
const MENU = @json($menu);
const OUTLET = @json($outlet);
const CASHIER = @json($cashier);
const RDATE = @json($receiptDate);
let cat = MENU[0].name, cart = [], orderType = 'Dine-in', payMethod = 'Tunai', given = 0, seq = 43;

const rp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

function renderCats(){
  document.getElementById('cats').innerHTML = MENU.map(c =>
    `<button class="${c.name===cat?'on':''}" onclick="setCat('${c.name}')">${c.icon} ${c.name}</button>`).join('');
}
function setCat(c){ cat = c; renderCats(); renderGrid(); }

function renderGrid(){
  const q = document.getElementById('q').value.toLowerCase();
  const group = MENU.find(c => c.name === cat);
  const items = group.items.filter(i => !q || i.name.toLowerCase().includes(q));
  document.getElementById('grid').innerHTML = items.map((i, idx) => `
    <div class="item ${i.out?'out':''}" onclick="${i.out?'':`add('${cat}',${idx})`}">
      <div class="thumb" style="background:${group.tint}">${i.emoji}</div>
      <div class="nm">${i.name}</div>
      <div class="pr">${rp(i.price)}</div>
      <div class="tag">${i.out ? 'Habis hari ini' : (i.note || group.name)}</div>
    </div>`).join('') || '<div class="empty">Menu tidak ditemukan.</div>';
}

function add(catName, idx){
  const group = MENU.find(c => c.name === catName);
  const item = group.items[idx];
  const found = cart.find(l => l.name === item.name);
  if (found) { found.qty++; } else { cart.push({name:item.name, price:item.price, qty:1, note:item.mod||''}); }
  renderCart();
}
function chg(i, d){ cart[i].qty += d; if (cart[i].qty <= 0) cart.splice(i,1); renderCart(); }

function totals(){
  const sub = cart.reduce((s,l) => s + l.price*l.qty, 0);
  const disc = sub >= 300000 ? Math.round(sub*0.05) : 0;
  const base = sub - disc;
  const serv = Math.round(base*0.05);
  const tax = Math.round((base+serv)*0.10);
  const raw = base + serv + tax;
  const total = Math.round(raw/100)*100;
  return {sub, disc, serv, tax, round: total-raw, total};
}

function renderCart(){
  const t = totals();
  document.getElementById('lines').innerHTML = cart.length ? cart.map((l,i) => `
    <div class="line">
      <div class="nm">${l.name}${l.note?`<div class="mod">${l.note}</div>`:''}
        <div class="qty" style="margin-top:6px">
          <button onclick="chg(${i},-1)">−</button><span>${l.qty}</span><button onclick="chg(${i},1)">+</button>
        </div>
      </div>
      <div class="amt">${rp(l.price*l.qty)}</div>
    </div>`).join('')
    : '<div class="empty">Belum ada item.<br>Ketuk menu di sebelah kiri untuk menambahkan.</div>';
  document.getElementById('sSub').textContent = rp(t.sub);
  document.getElementById('sDisc').textContent = t.disc ? '− ' + rp(t.disc) : 'Rp 0';
  document.getElementById('sServ').textContent = rp(t.serv);
  document.getElementById('sTax').textContent = rp(t.tax);
  document.getElementById('sRound').textContent = (t.round>=0?'':'− ') + rp(Math.abs(t.round));
  document.getElementById('sTotal').textContent = rp(t.total);
  document.getElementById('payBtn').disabled = cart.length === 0;
}

function openPay(){
  const t = totals();
  document.getElementById('payTotal').textContent = rp(t.total);
  document.getElementById('payCount').textContent = cart.reduce((s,l)=>s+l.qty,0);
  const opts = [t.total, Math.ceil(t.total/50000)*50000, Math.ceil(t.total/100000)*100000, Math.ceil(t.total/100000)*100000 + 100000];
  document.getElementById('cashBtns').innerHTML = [...new Set(opts)].map(v =>
    `<button onclick="setGiven(${v})">${rp(v)}</button>`).join('');
  setGiven(t.total);
  document.getElementById('payModal').classList.add('on');
}
function closePay(){ document.getElementById('payModal').classList.remove('on'); }
function setGiven(v){
  given = v;
  const t = totals();
  document.getElementById('cashGiven').textContent = rp(v);
  document.getElementById('cashBack').textContent = rp(Math.max(0, v - t.total));
}

function finish(){
  const t = totals();
  const no = 'KMG-01-' + RDATE + '-' + String(seq).padStart(4,'0');
  const pad = (a,b) => a + ' '.repeat(Math.max(1, 38 - a.length - b.length)) + b;
  let s = '';
  s += '        ' + OUTLET + '\n';
  s += '   Jl. Kemang Raya No. 24, Jakarta\n';
  s += '--------------------------------------\n';
  s += no + '\n' + new Date().toLocaleString('id-ID') + '  ' + orderType + '\n';
  s += 'Kasir: ' + CASHIER + '\n';
  s += '--------------------------------------\n';
  cart.forEach(l => {
    s += l.name + '\n';
    s += pad('  ' + l.qty + ' x ' + rp(l.price), rp(l.qty*l.price)) + '\n';
  });
  s += '--------------------------------------\n';
  s += pad('Subtotal', rp(t.sub)) + '\n';
  if (t.disc) s += pad('Diskon 5%', '-' + rp(t.disc)) + '\n';
  s += pad('Service charge 5%', rp(t.serv)) + '\n';
  s += pad('PB1 10%', rp(t.tax)) + '\n';
  s += pad('Pembulatan', rp(t.round)) + '\n';
  s += pad('TOTAL', rp(t.total)) + '\n';
  s += pad(payMethod, rp(payMethod === 'Tunai' ? given : t.total)) + '\n';
  if (payMethod === 'Tunai') s += pad('Kembalian', rp(Math.max(0, given - t.total))) + '\n';
  s += '--------------------------------------\n';
  s += '      Terima kasih atas kunjungan\n           Anda. Sampai jumpa!\n';
  document.getElementById('rcpt').textContent = s;
  closePay();
  document.getElementById('rcptModal').classList.add('on');
  seq++;
}
function newOrder(){
  cart = []; renderCart();
  document.getElementById('rcptModal').classList.remove('on');
  document.getElementById('orderNo').textContent = 'KMG-01-' + RDATE + '-' + String(seq).padStart(4,'0');
}
function hold(){ alert('Pesanan ditahan. Dapat dibuka kembali dari layar Pesanan.'); }
function kitchen(){
  if (!cart.length) { alert('Belum ada item.'); return; }
  alert('Tiket dikirim ke printer dapur & bar.\n\nDi sistem sebenarnya, inilah saat stok bahan terpotong sesuai resep.');
}

document.querySelectorAll('.types button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.types button').forEach(x => x.classList.remove('on'));
  b.classList.add('on'); orderType = b.dataset.type;
});
document.querySelectorAll('.pays button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.pays button').forEach(x => x.classList.remove('on'));
  b.classList.add('on'); payMethod = b.dataset.pay;
  document.getElementById('cashBox').style.display = payMethod === 'Tunai' ? 'block' : 'none';
});
document.querySelectorAll('.rail button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.rail button').forEach(x => x.classList.remove('on'));
  b.classList.add('on');
  const target = b.dataset.scr;
  document.getElementById('scr-kasir').style.display = target === 'kasir' ? 'flex' : 'none';
  document.getElementById('cartPanel').style.display = target === 'kasir' ? 'flex' : 'none';
  ['pesanan','shift','stok','laporan','pengaturan'].forEach(s =>
    document.getElementById('scr-' + s).classList.toggle('on', s === target));
});
document.getElementById('q').addEventListener('input', renderGrid);
setInterval(() => {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'});
}, 1000);
document.getElementById('clock').textContent = new Date().toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'});
renderCats(); renderGrid(); renderCart();
</script>
</body>
</html>
